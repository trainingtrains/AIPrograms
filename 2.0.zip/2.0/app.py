from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)

# Load Tirukkural data from JSON file
with open('thirukkural.json', 'r', encoding='utf-8') as file:
    thirukkural_data = json.load(file)['kural']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_kural', methods=['POST'])
def get_kural():
    kural_number = int(request.form['kural-number'])

    for kural in thirukkural_data:
        if kural['Number'] == kural_number:
            return jsonify(kural)
    
    return jsonify({'error': 'Kural not found'})

if __name__ == '__main__':
    app.run(debug=True)
